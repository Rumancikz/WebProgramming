//  * Program:  script.js 

//  * purpose: script of Group Project 4

//  * Objectives: 1) Comments; 2) tags ; 3)elements ; 4)documentation 

//  * Class: CSC 3323 - Web Programming; Fall 2020; TR: 645PM - 800PM  

//  * Instructor: Dr. Fazelpour - Copyright © 2020  

//  * Programmer(s): Team 1 - Rumancik, Zach (ZWR); Ragoonanan, Jaggan  

//  * Date: 11/12/2020